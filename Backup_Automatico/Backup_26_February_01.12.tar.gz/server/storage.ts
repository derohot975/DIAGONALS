import { storage } from "./storage/index";
export { storage };
export type { IStorage } from "./storage/index"; // Not used but for consistency
